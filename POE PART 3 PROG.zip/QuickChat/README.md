# QuickChat (PROG5121 PoE)

Console chat application (Parts 1-3): registration, login, sending / storing / disregarding
messages, JSON storage and the Stored Messages menu.

Run tests:  `mvn test`
Run app:    `mvn compile exec:java -Dexec.mainClass=com.quickchat.Main`
(or run `Main.java` from NetBeans / IntelliJ)
