package com.quickchat;

import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Part 2 and Part 3 unit tests. */
public class MessageTest {

    // Fixed IDs so the tests are repeatable (developer entry of the test data)
    private static final String ID1 = "1011111111";
    private static final String ID2 = "2022222222";
    private static final String ID3 = "3033333333";
    private static final String ID4 = "4044444444";
    private static final String ID5 = "5055555555";

    private static final String M1 = "Did you get the cake?";
    private static final String M2 = "Where are you? You are late! I have asked you to be on time.";
    private static final String M3 = "Yohoooo, I am at your gate.";
    private static final String M4 = "It is dinner time!";
    private static final String M5 = "Ok, I am leaving without you.";

    private Message messages;

    /** Developer entry of the Part 3 test data (messages 1-5), using a temporary JSON file. */
    @BeforeEach
    void setUp() throws IOException {
        File temp = File.createTempFile("quickchat", ".json");
        temp.deleteOnExit();
        messages = new Message(temp.getAbsolutePath());
        messages.addMessage(ID1, "+27834557896", M1, Message.SENT);
        messages.addMessage(ID2, "+27838884567", M2, Message.STORED);
        messages.addMessage(ID3, "+27834484567", M3, Message.DISREGARD);
        messages.addMessage(ID4, "0838884567", M4, Message.SENT);
        messages.addMessage(ID5, "+27838884567", M5, Message.STORED);
    }

    // ---------------- Part 2 tests ----------------

    @Test
    void messageLengthSuccess() {
        assertEquals("Message ready to send.", messages.checkMessageLength(M1));
    }

    @Test
    void messageLengthFailure() {
        String longText = "a".repeat(260);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.",
                messages.checkMessageLength(longText));
    }

    @Test
    void recipientNumberSuccessAndFailure() {
        assertEquals("Cell phone number successfully captured.",
                messages.checkRecipientCell("+27718693002"));
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. "
                + "Please correct the number and try again.", messages.checkRecipientCell("08575975889"));
    }

    @Test
    void messageHashIsCorrect() {
        // Test case 1 from Part 2
        assertEquals("00:0:HITONIGHT",
                messages.createMessageHash("0012345678", 0, "Hi Mike, can you join us for dinner tonight?"));
        assertEquals("00:1:HIPAYMENT",
                messages.createMessageHash("0098765432", 1, "Hi Keegan, did you receive the payment?"));
    }

    @Test
    void messageIdIsCreated() {
        String id = messages.generateMessageId();
        assertTrue(messages.checkMessageID(id));
        assertEquals(10, id.length());
    }

    @Test
    void sentMessageOptions() {
        assertEquals("Message successfully sent.", messages.sentMessage(1));
        assertEquals("Press 0 to delete the message.", messages.sentMessage(2));
        assertEquals("Message successfully stored.", messages.sentMessage(3));
    }

    @Test
    void totalMessagesSentIsCounted() {
        assertEquals(2, messages.returnTotalMessages());
    }

    // ---------------- Part 3 tests ----------------

    @Test
    void sentMessagesArrayCorrectlyPopulated() {
        assertEquals(Arrays.asList("Did you get the cake?", "It is dinner time!"),
                messages.getSentMessages());
    }

    @Test
    void disregardedAndStoredArraysPopulated() {
        assertEquals(Arrays.asList(M3), messages.getDisregardedMessages());
        assertEquals(Arrays.asList(M2, M5), messages.getStoredMessages());
        assertEquals(5, messages.getMessageHashes().size());
        assertEquals(5, messages.getMessageIDs().size());
    }

    @Test
    void displayLongestMessage() {
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                messages.displayLongestMessage());
    }

    @Test
    void searchForMessageId() {
        assertEquals("It is dinner time!", messages.getMessageTextById(ID4));
        assertEquals("Recipient: 0838884567 | Message: It is dinner time!",
                messages.searchByMessageId(ID4));
        assertEquals("Message ID not found.", messages.searchByMessageId("9999999999"));
    }

    @Test
    void searchMessagesForRecipient() {
        assertEquals(Arrays.asList("Where are you? You are late! I have asked you to be on time.",
                "Ok, I am leaving without you."), messages.searchByRecipient("+27838884567"));
    }

    @Test
    void deleteMessageUsingHash() {
        String hash = messages.getMessageHashes().get(1); // Test message 2
        assertEquals("Message: \"Where are you? You are late! I have asked you to be on time.\" "
                + "successfully deleted.", messages.deleteByHash(hash));
        assertEquals(Arrays.asList(M5), messages.getStoredMessages());
        assertEquals("Message hash not found.", messages.deleteByHash(hash));
    }

    @Test
    void displayReportShowsHashRecipientAndMessage() {
        String report = messages.displaySentReport();
        assertTrue(report.contains(messages.getMessageHashes().get(0)));
        assertTrue(report.contains("+27834557896"));
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("0838884567"));
        assertTrue(report.contains("It is dinner time!"));
    }

    @Test
    void storedMessagesAreWrittenToAndReadFromJson() throws IOException {
        File temp = File.createTempFile("quickchat-read", ".json");
        temp.deleteOnExit();
        Message writer = new Message(temp.getAbsolutePath());
        writer.addMessage(ID2, "+27838884567", M2, Message.STORED);
        writer.addMessage(ID5, "+27838884567", M5, Message.STORED);

        Message reader = new Message(temp.getAbsolutePath());
        assertEquals(2, reader.loadStoredMessages());
        assertEquals(Arrays.asList(M2, M5), reader.getStoredMessages());
    }
}
